var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/save-artifact.js
var save_artifact_exports = {};
__export(save_artifact_exports, {
  default: () => save_artifact_default
});
module.exports = __toCommonJS(save_artifact_exports);
var import_blobs = require("@netlify/blobs");
var save_artifact_default = async (req, context) => {
  const { slug, html } = await req.json();
  const store = (0, import_blobs.getStore)("artifacts");
  await store.set(slug, html);
  const siteUrl = Netlify.env.get("URL") || "https://steady-nougat-d7a876.netlify.app";
  return Response.json({ url: `${siteUrl}/artifact/${slug}` });
};
