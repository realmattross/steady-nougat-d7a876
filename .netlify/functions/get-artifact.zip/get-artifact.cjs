var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/get-artifact.js
var get_artifact_exports = {};
__export(get_artifact_exports, {
  config: () => config,
  default: () => get_artifact_default
});
module.exports = __toCommonJS(get_artifact_exports);
var import_blobs = require("@netlify/blobs");
var get_artifact_default = async (req, context) => {
  const slug = context.params.slug;
  const store = (0, import_blobs.getStore)("artifacts");
  const html = await store.get(slug);
  if (!html) return new Response("Not found", { status: 404 });
  return new Response(html, { headers: { "Content-Type": "text/html" } });
};
var config = { path: "/artifact/:slug" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
